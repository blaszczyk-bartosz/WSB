<?php
    $host = "localhost";    //nazwa hosta, na którym baza jest postawiona
    $db_user = "root";      //nazwa użytkownika bazy
    $db_password ="";       //hasło o ile jest nadane
    $db_name = "klienci";   //nazwa bazy danych, nie tabeli
?>